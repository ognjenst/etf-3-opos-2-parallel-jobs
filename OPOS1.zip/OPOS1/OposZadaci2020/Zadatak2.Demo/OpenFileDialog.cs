﻿namespace Zadatak2.Demo
{
    internal class OpenFileDialog
    {
    }
}